import React from 'react';
import { View, StyleSheet } from 'react-native';

const GOLD = '#f0c040';
const INACTIVE = '#777';

interface Props {
  color?: string;
  size?: number;
}

// 2×2 grid squares
export function GridIcon({ color = INACTIVE, size = 22 }: Props) {
  const sq = size * 0.38;
  const gap = size * 0.1;
  return (
    <View style={{ width: size, height: size, justifyContent: 'center', alignItems: 'center' }}>
      <View style={{ flexDirection: 'row', gap }}>
        <View style={{ width: sq, height: sq, borderRadius: 2, backgroundColor: color }} />
        <View style={{ width: sq, height: sq, borderRadius: 2, backgroundColor: color }} />
      </View>
      <View style={{ height: gap }} />
      <View style={{ flexDirection: 'row', gap }}>
        <View style={{ width: sq, height: sq, borderRadius: 2, backgroundColor: color }} />
        <View style={{ width: sq, height: sq, borderRadius: 2, backgroundColor: color }} />
      </View>
    </View>
  );
}

// 3 vertical bars (signal / bar chart style)
export function SignalIcon({ color = INACTIVE, size = 22 }: Props) {
  const w = size * 0.18;
  const gap = size * 0.08;
  const r = 2;
  return (
    <View style={{ width: size, height: size, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'center', gap }}>
      <View style={{ width: w, height: size * 0.45, borderRadius: r, backgroundColor: color }} />
      <View style={{ width: w, height: size * 0.70, borderRadius: r, backgroundColor: color }} />
      <View style={{ width: w, height: size * 1.00, borderRadius: r, backgroundColor: color }} />
    </View>
  );
}

// Rising line chart (Fibo / trending up)
export function FiboIcon({ color = INACTIVE, size = 22 }: Props) {
  const s = size;
  const t = Math.max(1.5, size * 0.08); // line thickness
  return (
    <View style={{ width: s, height: s, justifyContent: 'center', alignItems: 'center' }}>
      {/* two segments of a rising zigzag */}
      {/* segment 1: bottom-left to mid-right going up */}
      <View style={[
        {
          position: 'absolute',
          width: s * 0.5,
          height: t,
          backgroundColor: color,
          borderRadius: t,
          left: 0,
          bottom: s * 0.25,
          transform: [{ rotate: '-30deg' }],
        }
      ]} />
      {/* segment 2: mid to top-right going up steeper */}
      <View style={[
        {
          position: 'absolute',
          width: s * 0.55,
          height: t,
          backgroundColor: color,
          borderRadius: t,
          right: 0,
          bottom: s * 0.42,
          transform: [{ rotate: '-45deg' }],
        }
      ]} />
      {/* dot at start */}
      <View style={{
        position: 'absolute',
        width: t * 2.2,
        height: t * 2.2,
        borderRadius: t,
        backgroundColor: color,
        left: 0,
        bottom: s * 0.18,
      }} />
      {/* dot at end */}
      <View style={{
        position: 'absolute',
        width: t * 2.2,
        height: t * 2.2,
        borderRadius: t,
        backgroundColor: color,
        right: 0,
        top: s * 0.08,
      }} />
    </View>
  );
}

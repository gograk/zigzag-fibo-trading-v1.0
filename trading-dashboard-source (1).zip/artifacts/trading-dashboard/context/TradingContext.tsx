import React, { createContext, useContext, useEffect, useRef, useState } from 'react';

export type Timeframe = '5M' | '15M' | '30M' | '1H' | '4H';

export interface FiboLevel {
  label: string;
  value: number;
  type: 'sell' | 'neutral' | 'buy' | 'sl' | 'high' | 'mid' | 'low';
}

export interface TimeframeFibo {
  tf: Timeframe;
  high: number;
  low: number;
  levels: FiboLevel[];
  rsi: number;
  zigzagDir: 'UP' | 'DOWN';
}

export interface Signal {
  id: string;
  tf: Timeframe;
  type: 'BUY' | 'SELL';
  entry: number;
  tp: number;
  sl: number;
  status: 'OPEN' | 'WIN' | 'LOSS' | 'PENDING';
  time: string;
  pnl: number;
}

export interface Stats {
  totalSinyal: number;
  win: number;
  loss: number;
  plHarian: number;
  maxDrawdown: number;
  uptime: string;
}

export interface LogEntry {
  time: string;
  message: string;
  type: 'info' | 'warn' | 'error';
}

interface TradingContextType {
  symbol: string;
  price: number;
  priceChange: number;
  rsiData: Record<Timeframe, number>;
  fiboData: TimeframeFibo[];
  signals: Signal[];
  stats: Stats;
  logs: LogEntry[];
}

const TIMEFRAMES: Timeframe[] = ['5M', '15M', '30M', '1H', '4H'];

function makeFiboLevels(high: number, low: number): FiboLevel[] {
  const range = high - low;
  return [
    { label: '[1.Sel2] A', value: +(high + range * 0.382).toFixed(3), type: 'sell' },
    { label: '[1.Sel2] B', value: +(high + range * 0.236).toFixed(3), type: 'sell' },
    { label: '[1.Sel1] A', value: +(high + range * 0.118).toFixed(3), type: 'sell' },
    { label: '[1.Sel1] B', value: +(high + range * 0.05).toFixed(3), type: 'sell' },
    { label: '[ ] HIGH', value: +high.toFixed(3), type: 'high' },
    { label: '[ ] MID', value: +((high + low) / 2).toFixed(3), type: 'mid' },
    { label: '[ ] LOW', value: +low.toFixed(3), type: 'low' },
    { label: '[1.Buy1] A', value: +(low - range * 0.05).toFixed(3), type: 'buy' },
    { label: '[1.Buy1] B', value: +(low - range * 0.118).toFixed(3), type: 'buy' },
    { label: '[1.Buy2] A', value: +(low - range * 0.236).toFixed(3), type: 'buy' },
    { label: '[1.Buy2] B', value: +(low - range * 0.382).toFixed(3), type: 'buy' },
    { label: '[SL Buy1]', value: +(low - range * 0.5).toFixed(3), type: 'sl' },
    { label: '[SL Buy2]', value: +(low - range * 0.618).toFixed(3), type: 'sl' },
  ];
}

const BASE_PRICE = 3022.850;

const INITIAL_FIBO: TimeframeFibo[] = [
  { tf: '5M',  high: 3029.445, low: 3018.320, rsi: 42, zigzagDir: 'DOWN', levels: makeFiboLevels(3029.445, 3018.320) },
  { tf: '15M', high: 3035.720, low: 3015.880, rsi: 55, zigzagDir: 'UP',   levels: makeFiboLevels(3035.720, 3015.880) },
  { tf: '30M', high: 3041.990, low: 3008.450, rsi: 50, zigzagDir: 'DOWN', levels: makeFiboLevels(3041.990, 3008.450) },
  { tf: '1H',  high: 3058.340, low: 2995.600, rsi: 59, zigzagDir: 'UP',   levels: makeFiboLevels(3058.340, 2995.600) },
  { tf: '4H',  high: 3089.110, low: 2955.220, rsi: 41, zigzagDir: 'DOWN', levels: makeFiboLevels(3089.110, 2955.220) },
];

const INITIAL_SIGNALS: Signal[] = [
  { id: '1', tf: '1H',  type: 'BUY',  entry: 3015.500, tp: 3030.000, sl: 3005.000, status: 'WIN',  time: '04:12', pnl: 14.5 },
  { id: '2', tf: '4H',  type: 'SELL', entry: 3041.200, tp: 3020.000, sl: 3055.000, status: 'LOSS', time: '03:45', pnl: -13.2 },
  { id: '3', tf: '15M', type: 'BUY',  entry: 3018.750, tp: 3025.000, sl: 3012.000, status: 'OPEN', time: '04:08', pnl: 0 },
  { id: '4', tf: '30M', type: 'SELL', entry: 3035.000, tp: 3022.000, sl: 3045.000, status: 'WIN',  time: '03:30', pnl: 13.0 },
  { id: '5', tf: '5M',  type: 'BUY',  entry: 3020.100, tp: 3024.000, sl: 3016.000, status: 'PENDING', time: '04:10', pnl: 0 },
];

const INITIAL_LOGS: LogEntry[] = [
  { time: '04:11:04', message: '[MT] ===>+4000.201 +2065.33 RSI=40.4', type: 'info' },
  { time: '04:11:07', message: '[MT] WS: CONNECT_CRYPT_HTTPCRT_P2017 cert: unable to get local issuer cert (Last: 6093)', type: 'warn' },
  { time: '04:51:47', message: '[MT] Closed, reconnect. 5s', type: 'info' },
  { time: '04:51:47', message: '[MT] WS: DIAG_CrtY_x8649 y_XAUUSC cert: unable to verify (Last: 6093)', type: 'warn' },
  { time: '04:12:02', message: '[MT] Closed, reconnect. 5s', type: 'info' },
];

const TradingContext = createContext<TradingContextType>({
  symbol: 'XAUUSD',
  price: BASE_PRICE,
  priceChange: 0,
  rsiData: { '5M': 42, '15M': 55, '30M': 50, '1H': 59, '4H': 41 },
  fiboData: INITIAL_FIBO,
  signals: INITIAL_SIGNALS,
  stats: { totalSinyal: 0, win: 0, loss: 0, plHarian: 0, maxDrawdown: 0, uptime: '0:06:31' },
  logs: INITIAL_LOGS,
});

export function TradingProvider({ children }: { children: React.ReactNode }) {
  const [price, setPrice] = useState(BASE_PRICE);
  const [priceChange, setPriceChange] = useState(0);
  const [rsiData, setRsiData] = useState<Record<Timeframe, number>>({
    '5M': 42, '15M': 55, '30M': 50, '1H': 59, '4H': 41,
  });
  const [fiboData] = useState<TimeframeFibo[]>(INITIAL_FIBO);
  const [signals] = useState<Signal[]>(INITIAL_SIGNALS);
  const [logs, setLogs] = useState<LogEntry[]>(INITIAL_LOGS);
  const [uptime, setUptime] = useState(391); // seconds
  const startTime = useRef(Date.now());

  const totalSinyal = signals.length;
  const win = signals.filter(s => s.status === 'WIN').length;
  const loss = signals.filter(s => s.status === 'LOSS').length;
  const plHarian = signals.reduce((sum, s) => sum + s.pnl, 0);

  const stats: Stats = {
    totalSinyal,
    win,
    loss,
    plHarian,
    maxDrawdown: 13.2,
    uptime: formatUptime(uptime),
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const delta = (Math.random() - 0.5) * 0.3;
      setPrice(p => {
        const next = +(p + delta).toFixed(3);
        setPriceChange(+(next - BASE_PRICE).toFixed(3));
        return next;
      });
      setRsiData(prev => {
        const next = { ...prev };
        for (const tf of TIMEFRAMES) {
          const noise = (Math.random() - 0.5) * 0.5;
          next[tf] = Math.min(100, Math.max(0, +(prev[tf] + noise).toFixed(1)));
        }
        return next;
      });
      setUptime(s => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const logInterval = setInterval(() => {
      const now = new Date();
      const h = String(now.getHours()).padStart(2, '0');
      const m = String(now.getMinutes()).padStart(2, '0');
      const s = String(now.getSeconds()).padStart(2, '0');
      setLogs(prev => [
        { time: `${h}:${m}:${s}`, message: `[MT] Price updated: XAUUSD ${price.toFixed(3)}`, type: 'info' },
        ...prev.slice(0, 19),
      ]);
    }, 5000);
    return () => clearInterval(logInterval);
  }, [price]);

  return (
    <TradingContext.Provider value={{
      symbol: 'XAUUSD',
      price,
      priceChange,
      rsiData,
      fiboData,
      signals,
      stats,
      logs,
    }}>
      {children}
    </TradingContext.Provider>
  );
}

function formatUptime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function useTrading() {
  return useContext(TradingContext);
}
